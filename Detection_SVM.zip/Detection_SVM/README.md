# MiAI_LP_Detection_SVM
Use WPOD and SVM to detect license plate

Article link:  http://ainoodle.tech/2019/12/05/nhan-dien-bien-so-xe-chuong-5-nhan-dien-bien-so-xe-bang-wpod-va-svm/

#MìAI <br>
Fanpage: http://facebook.com/miaiblog<br>
Group trao đổi, chia sẻ: https://www.facebook.com/groups/miaigroup<br>
Website: http://miai.vn<br>
Youtube: http://bit.ly/miaiyoutube<br>
